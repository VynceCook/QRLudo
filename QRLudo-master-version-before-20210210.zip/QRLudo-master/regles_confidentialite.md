# Règles de confidentialité de QR Ludo

Date de dernière modification : 30 Janvier 2020

## Appareil photo
Il est utilisé pour scanner les QR Codes. Aucune photo ou vidéo ne sont prises et aucune donnée n'est envoyée via internet.

## Accès à Internet
Nous accèdons à internet pour le téléchargement des fichiers qui sont stockés dans les QR Codes. Aucune donnée n’est envoyée via internet.

## Accès au système de fichiers
Nous avons besoin de l'accès aux fichiers pour sauvegarder les fichiers son téléchargés, et y accéder pour leurs lectures. Aucune donnée n’est envoyée via internet.

## Données personnelles
Aucune donnée personnelle n’est collectée par QR Ludo.
