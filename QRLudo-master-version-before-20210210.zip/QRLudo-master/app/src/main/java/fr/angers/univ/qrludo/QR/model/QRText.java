package fr.angers.univ.qrludo.QR.model;

/**
 * Created by Jules Leguy on 20/01/18.
 */

public class QRText extends QRContent {

    public QRText(String text){
        super(text);
    }

}
