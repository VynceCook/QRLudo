package fr.angers.univ.qrludo.atom;

public class EnigmeAtom extends Atom {

    public String toString() { return "EnigmeAtom";}

    @Override
    public String getContent() {
        return null;
    }
}
