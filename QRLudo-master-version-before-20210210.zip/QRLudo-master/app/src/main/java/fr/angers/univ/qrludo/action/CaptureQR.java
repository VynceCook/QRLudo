package fr.angers.univ.qrludo.action;

import fr.angers.univ.qrludo.activities.MainActivity;

public class CaptureQR extends Action {

    public CaptureQR(MainActivity mainActivity, int nodeID){
        super(mainActivity,nodeID);
    }

    public String toString() {return "CaptureQR";}
}
