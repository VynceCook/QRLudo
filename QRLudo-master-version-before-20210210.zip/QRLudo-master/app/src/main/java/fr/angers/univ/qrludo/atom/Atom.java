package fr.angers.univ.qrludo.atom;

public abstract class Atom {

    public abstract String toString();

    public abstract String getContent();
}
