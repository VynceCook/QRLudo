# Changelog

## Version 1.2
- Correction de bugs
- Modification des gestes utilisateurs des QR Exercices
- Ajout des questions ouvertes à reconnaissance vocale
- Nouveau système de QCM à reconnaissance vocale
- Ajout des Serious Game
- Ajout du menu aide contenant les mouvements de l'application

## Version 1.1
- Correction de bugs
- Changement des QR Code Ensemble en QR Code Multiple
- Ajout des QR QCM
- Ajout des QR Exercice
- Ouverture ou lecture de liens Web
- Amélioration de l'interface
- Retour en arrière dans la lecture
- Modification des gestes utilisateurs
- Support de la version 3 et 4 des QR Codes


## Version 1.0

- Compression des QR au format JSON
- QR Code uniques
- QR Code Ensemble
- Utilisation de fichiers sons

